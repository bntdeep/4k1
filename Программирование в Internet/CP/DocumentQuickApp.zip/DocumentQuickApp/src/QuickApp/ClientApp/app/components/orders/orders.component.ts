import { Component, ViewChild, OnInit } from '@angular/core';
import { fadeInOut } from '../../services/animations';

import { UploadFile } from '../../services/upload-file.service';
import { StegoContainerInfoDTO } from '../../models/stegoContainerInfoDTO';


import { AlertService, MessageSeverity } from '../../services/alert.service';

@Component({
    selector: 'orders',
    templateUrl: './orders.component.html',
    styleUrls: ['./orders.component.css'],
    animations: [fadeInOut]
})
export class OrdersComponent {

    @ViewChild("fileInput") fileInput;
    @ViewChild("messageLanguage") messageLanguage;
    dto: StegoContainerInfoDTO;
    isExtractedMessageVisible: boolean;


    constructor(private uploadService: UploadFile, private alertService: AlertService) {
        this.dto = new StegoContainerInfoDTO();
        this.messageLanguage = 'ENGLISH';
    }

    ngOnInit() {
        this.messageLanguage = 'ENGLISH';
        this.isExtractedMessageVisible = false;
    }

    selectFile(fileInput: any) {
        if (fileInput.target.files && fileInput.target.files[0]) {
            let fileToUpload = fileInput.target.files[0];

            this.uploadService
                .uploadFileToExtractMessage(fileToUpload, this.messageLanguage)
                .subscribe(res => {
                    this.dto = res;
                    this.isExtractedMessageVisible = true;
                    console.log('-----stego dto is-----:');
                    console.log(this.dto);
                    this.showErrorSuccess("Embedding result", "Message was embedded");
                });
        }
    }

    private showErrorSuccess(caption: string, message: string) {
        this.alertService.showMessage(caption, message, MessageSeverity.success);
    }
}

﻿export enum Gender {
    None,
    Female,
    Male
}
﻿export class StegoContainerInfoDTO {
    constructor(name?: string,
                size?: number,
                bitsPerSymbol?: number,
                embeddingMessage?: string,
                finalContainerName?: string)
    {

        this.name = name;
        this.size = size;
        this.bitsPerSymbol = bitsPerSymbol;
        this.embeddingMessage = embeddingMessage;
        this.finalContainerName = finalContainerName;
    }

     public name: string;
     public size: number;
     public bitsPerSymbol: number;
     public embeddingMessage: string;
     public finalContainerName: string;
}
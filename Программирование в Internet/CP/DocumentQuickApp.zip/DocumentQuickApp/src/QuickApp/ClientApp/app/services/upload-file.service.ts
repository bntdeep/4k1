﻿import { Injectable, Injector } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { EndpointFactory } from './endpoint-factory.service';
import { ConfigurationService } from './configuration.service';

import { StegoContainerInfoDTO } from '../models/stegoContainerInfoDTO';


@Injectable()
export class UploadFile extends EndpointFactory {

    private readonly _uploadUrlFile: string = "/api/uploadFile";
    private readonly _uploadUrlMessageLanguage: string = "/api/uploadMessageLanguage";
    private readonly _uploadUrlMessage: string = "/api/uploadMessage";
    private readonly _uploadUrlFinalContainerName: string = "/api/uploadFinalContainerName";
    private readonly _downloadContainerUrl: string = "/api/downloadContainer"; 
    private readonly _removeTempZipArchive: string = "/api/removeTempZipArchive";


    private readonly _uploadUrlExtractMessage: string = "/api/uploadFileToExtract";
  
    get uploadUrlFile() { return this.configurations.baseUrl + this._uploadUrlFile; }
    get uploadUrlLanguage() { return this.configurations.baseUrl + this._uploadUrlMessageLanguage; }
    get uploadUrlMessage() { return this.configurations.baseUrl + this._uploadUrlMessage; }
    get uploadUrlFinalContainerName() { return this.configurations.baseUrl + this._uploadUrlFinalContainerName; }
    get downloadContainerUrl() { return this.configurations.baseUrl + this._downloadContainerUrl; }
    get removeUrlTempZipArchive() { return this.configurations.baseUrl + this._removeTempZipArchive; }
    get uploadUrlExtractMessage() { return this.configurations.baseUrl + this._uploadUrlExtractMessage; }
   

    constructor(http: Http, configurations: ConfigurationService, injector: Injector) {

        super(http, configurations, injector);
    }

    uploadFile(fileToUpload: any): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("file", fileToUpload);
        return this.http
            .post(this.uploadUrlFile, input)
            .map(res => res.json())
            .catch(this.handleError);
    }

    uploadFileToExtractMessage(fileToUpload: any, messageLanguage: string): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("file", fileToUpload);
        input.append("extractMessageLanguage", messageLanguage);

        return this.http
            .post(this.uploadUrlExtractMessage, input)
            .map(res => res.json())
            .catch(this.handleError);
    }

    uploadLanguage(language: string): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("language", language);

        return this.http
            .post(this.uploadUrlLanguage, input)
            .map(res => res.json())
            .catch(this.handleError);
    }

    uploadMessage(message: string): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("message", message);

        return this.http
            .post(this.uploadUrlMessage, input)
            .map(res => res.json())
            .catch(this.handleError);
    }

    uploadFinalContainerName(name: string): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("name", name);

        return this.http
            .post(this.uploadUrlFinalContainerName, input)
            .map(res => res.json())
            .catch(this.handleError);
    }

    downloadStegoContainer(containerName: string): void {
        window.open(this.downloadContainerUrl);
    }   

    removeTempZipArchive(archiveName: string): Observable<StegoContainerInfoDTO> {
        let input = new FormData();
        input.append("archiveName", archiveName);

        return this.http
            .post(this.removeUrlTempZipArchive, input)
            .map(res => res.json())
            .catch(this.handleError);
    }  

    handleError(error: any) {
        console.log('My HandleError is working');
        console.error('Service error', error);
        return Observable.throw(error.message || error);
    }
}
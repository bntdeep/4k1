import { Component, ViewChild, OnDestroy, OnInit } from '@angular/core';
import { fadeInOut } from '../../services/animations';


import { Http, RequestOptions, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { AlertService, MessageSeverity } from '../../services/alert.service';
import { ConfigurationService } from '../../services/configuration.service';
import { UploadFile } from '../../services/upload-file.service';

import { StegoContainerInfoDTO } from '../../models/stegoContainerInfoDTO';

import { saveAs } from 'file-saver';

@Component({
    selector: 'file-sender',
    templateUrl: './file-sender.component.html',
    styleUrls: ['./file-sender.component.css'],
    animations: [fadeInOut]
})
export class FileSenderComponent {

    dto: StegoContainerInfoDTO;
    isFileSelectorVisible: boolean;
    fileInputTempVariable: any;
    fileName: string;



    constructor(private uploadService: UploadFile, private configurations: ConfigurationService, private alertService: AlertService) {
        this.dto = new StegoContainerInfoDTO();
        this.isFileSelectorVisible = true;
    }

    @ViewChild("fileInput") fileInput;
    @ViewChild("messageLanguage") messageLanguage;
    @ViewChild("secretMessage") secretMessage;
    @ViewChild("finalContainerName") finalContainerName;


    ngOnDestroy() {
        this.uploadService
            .removeTempZipArchive(this.dto.name)
            .subscribe(res => {
                this.dto = res;
                console.log('-----stego dto is-----:');
                console.log(this.dto);
                this.isFileSelectorVisible = false;
            });
    }

    addFile(fileInput: any): void {
        if (fileInput.target.files && fileInput.target.files[0]) {
            let fileToUpload = fileInput.target.files[0];
            this.fileInputTempVariable = fileInput.target.files[0];

            this.sendDTOToServer();
        }
    }

    changeLagnuage(selectEvent: any) {
        console.log('massage language is: ' + this.messageLanguage);

        this.uploadService
            .uploadLanguage(this.messageLanguage)
            .subscribe(res => {
                this.dto = res;
                console.log('-----stego dto is-----:');
                console.log(this.dto);
                this.isFileSelectorVisible = false;
            });

    }

    secretMessgeChange(textChangedEvent: any) {
        console.log('secret message is: ' + this.secretMessage);

        this.uploadService
            .uploadMessage(this.secretMessage)
            .subscribe(res => {
                this.dto = res;
                console.log('-----stego dto is-----:');
                console.log(this.dto);
                this.isFileSelectorVisible = false;
            });        
    }

    sendDTOToServer() {
        this.uploadService
            .uploadFile(this.fileInputTempVariable)
            .subscribe(res => {
                this.dto = res;
                console.log('-----stego dto is-----:');
                console.log(this.dto);
                this.isFileSelectorVisible = false;
            });
    }

    downloadContainer(clickEvent: any) {

            this.uploadService
                .uploadFinalContainerName(this.finalContainerName).subscribe(res => {
                    this.dto = res;
                    console.log('-----stego dto is-----:');
                    console.log(this.dto);
                    this.isFileSelectorVisible = true;
                    this.showErrorSuccess("success message", "information is embedded");
                });

            this.uploadService
                .downloadStegoContainer("test.docx");

    }

    private showErrorSuccess(caption: string, message: string) {
        this.alertService.showMessage(caption, message, MessageSeverity.success);
    }
}

﻿namespace QuickApp.Models
{
    public enum SecretMessageLanguage
    {
        RUSSIAN,
        ENGLISH
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickApp.Models
{

    class DOCXFile
    {
        public XMLFile document { get; set; }
    }
}

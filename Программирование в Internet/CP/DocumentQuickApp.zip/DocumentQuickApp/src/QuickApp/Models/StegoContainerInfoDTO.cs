﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickApp.Models
{
    public class StegoContainerInfoDTO
    {
        public string Name { get; set; }
        public int Size { get; set; }
        public int BitsPerSymbol { get; set; }
        public string EmbeddingMessage { get; set; }
        public string FinalContainerName { get; set; }
    }
}

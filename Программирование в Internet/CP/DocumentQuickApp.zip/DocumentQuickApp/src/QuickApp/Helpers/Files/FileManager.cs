﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using QuickApp.Models;

namespace QuickApp.Helpers.Files
{
    class FileManager
    {

        private static readonly string tempArchiveStorage = "./tempStorage//";
        private static readonly string tempArchiveStorageLocation = "./";
        private static readonly string xmlFileContainsMainMarkup = "word/document.xml";

        public static string ReadHTMLFile(string path)
        {
            return File.ReadAllText(path);
        }

        public static void WriteHTMLFile(XMLFile HTMLFile, string path)
        {
            File.WriteAllText(path, HTMLFile.File.ToString());
        }
        
        public static void CopyFileAndChangeExtentionToZip(String file)
        {
            File.Copy(file, Path.ChangeExtension($"{tempArchiveStorage}{Path.GetFileName(file)}", ".zip"));
        }
        public static void CopyFileAndChangeExtentionToDOCX(String file, string fileDestination)
        {
            File.Copy(file, Path.ChangeExtension(fileDestination, ".docx"));
        }
        public static void DeleteTempArchive(string tempArchive)
        {
            File.Delete(tempArchive);
        }
        public static void DeleteTempFile(string tempFile)
        {
            File.Delete(tempFile);
        }

        public static string ReadDocumentFromZipFile(String filePath)
        {
            String fileContents = "";
            try
            {
                if (System.IO.File.Exists(filePath))
                {

                    System.IO.Compression.ZipArchive apcZipFile = System.IO.Compression.ZipFile.Open(filePath, System.IO.Compression.ZipArchiveMode.Read);
                    foreach (System.IO.Compression.ZipArchiveEntry entry in apcZipFile.Entries)
                    {
                        if (entry.FullName == xmlFileContainsMainMarkup)
                        {
                            System.IO.Compression.ZipArchiveEntry zipEntry = apcZipFile.GetEntry(entry.FullName);

                            using (System.IO.StreamReader sr = new System.IO.StreamReader(zipEntry.Open()))
                            {
                                fileContents = sr.ReadToEnd();
                            }
                        }
                    }
                    apcZipFile.Dispose();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return fileContents;
        }

        public static void RemoveDocumentFilefromZipArchive(string archivename, string removingDocument)
        {
            using (Stream stream = File.Open(archivename, FileMode.Open))
            {
                using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Update, false, null))
                {
                    ZipArchiveEntry entry = archive.GetEntry(removingDocument);
                    if (entry != null)
                    {
                        entry.Delete();
                    }
                }
            }
        }
    }
}

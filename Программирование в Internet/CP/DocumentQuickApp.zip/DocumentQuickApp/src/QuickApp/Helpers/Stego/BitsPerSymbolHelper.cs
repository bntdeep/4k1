﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuickApp.Models;

namespace QuickApp.Helpers.Stego
{
    public static class BitsPerSymbolHelper
    {
         public static Dictionary<SecretMessageLanguage, int> numOfBits = new Dictionary<SecretMessageLanguage, int>() {

             { SecretMessageLanguage.ENGLISH, 8 },
             { SecretMessageLanguage.RUSSIAN, 11 }
         };
    }
}

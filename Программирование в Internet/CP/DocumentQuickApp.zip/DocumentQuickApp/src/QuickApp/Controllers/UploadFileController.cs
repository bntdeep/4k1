﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;
using Newtonsoft.Json;

using QuickApp.Models;
using QuickApp.Helpers.Files;
using QuickApp.Helpers.Stego;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Collections.Generic;

namespace QuickApp.Controllers
{
    [Produces("application/json")]
    [Route("api/upload")]
    public class UploadFileController : Controller
    {
        public const string endOfMessageFlag = "!@#";
        public const string tempArchivesFolder = "./tempStorage";

        static DOCXFile docxContainer;
        static DOCXFile DOCXFileWithMessage = new DOCXFile();
        static string fileName = "";
        static string fileNameWithoutExtension = "";
        static SecretMessageLanguage messageLanguage = SecretMessageLanguage.ENGLISH;
        static string secretMessage = "";
        static string finalContainerName = "";

        [HttpPost]
        [Route("/api/uploadFile")]
        public async Task Upload(IFormFile file)
        {
            if (file == null) throw new Exception("File is null");
            if (file.Length == 0) throw new Exception("File is empty");

            if (file.Length > 0)
            {
                ClearTempFolder(tempArchivesFolder);

                using (var stream = new FileStream(Path.Combine(tempArchivesFolder, file.FileName), FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
            }

            fileName = file.FileName;
            fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);

            FileManager.CopyFileAndChangeExtentionToZip(Path.Combine(tempArchivesFolder, file.FileName));

            string xmlDocument = FileManager.ReadDocumentFromZipFile($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip");

            docxContainer = new DOCXFile();
            docxContainer.document = new XMLFile();
            docxContainer.document.File = new StringBuilder(xmlDocument);

            StegoContainerInfoDTO dto = MakeDTO();

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

        private static void ClearTempFolder(string tempFolder)
        {
            if (Directory.Exists(tempFolder))
            {
                foreach (FileInfo fi in new DirectoryInfo(tempFolder).GetFiles())
                {
                    fi.Delete();
                }
            }
            else
            {
                Directory.CreateDirectory(tempFolder);
            }
        }

        [HttpPost]
        [Route("/api/uploadMessageLanguage")]
        public async Task UploadLanguage(string language)
        {
            messageLanguage = (SecretMessageLanguage)Enum.Parse(typeof(SecretMessageLanguage), language);

            StegoContainerInfoDTO dto = MakeDTO();

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

        [HttpPost]
        [Route("/api/uploadFinalContainerName")]
        public async Task UploadFinalContainerName(string name)
        {
            finalContainerName = name;

            StegoContainerInfoDTO dto = MakeDTO();

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

        [HttpPost]
        [Route("/api/uploadMessage")]
        public async Task UploadMessage(string message)
        {
            secretMessage = message == null ? "" : message;

            StegoContainerInfoDTO dto = MakeDTO();

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

        [HttpPost]
        [Route("/api/removeTempZipArchive")]
        public async Task RemoveTempZipArchive(string archiveName)
        {
            if (docxContainer != null)
            {
                try
                {
                    FileManager.DeleteTempArchive($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip");

                    string pathToRemovingTempFile = $"{tempArchivesFolder}//{UploadFileController.fileName}";
                    FileManager.DeleteTempFile(pathToRemovingTempFile);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e + " archive of file does not exits");
                }
            }

            StegoContainerInfoDTO dto = new StegoContainerInfoDTO()
            {
                Name = "removed",
                BitsPerSymbol = 8,
                EmbeddingMessage = "no message",
                Size = 0,
                FinalContainerName = "not setted"
            };

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

        private StegoContainerInfoDTO MakeDTO()
        {
            int containerSize = (int)docxContainer.document
                                         .GetContainerCapacity(Convert.ToInt32(BitsPerSymbolHelper.numOfBits[messageLanguage])
                                         - endOfMessageFlag.Length);

            return new StegoContainerInfoDTO()
            {
                Name = fileName,
                BitsPerSymbol = BitsPerSymbolHelper.numOfBits[messageLanguage],
                EmbeddingMessage = secretMessage,
                Size = containerSize - secretMessage.Length,
                FinalContainerName = finalContainerName
            };
        }

        [HttpGet]
        [Route("/api/downloadContainer")]
        public async Task<IActionResult> Download(string filename)
        {
            if (docxContainer != null)
            {
                Embedder.EmbedMessage(docxContainer.document, secretMessage, BitsPerSymbolHelper.numOfBits[messageLanguage]);

                FileManager.RemoveDocumentFilefromZipArchive($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip", "word/document.xml");

                Embedder.AddStegoContainerToArchive($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip", "word/document.xml", docxContainer.document.File.ToString());

                FileManager.CopyFileAndChangeExtentionToDOCX($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip", Path.Combine(tempArchivesFolder, finalContainerName));
                FileManager.DeleteTempArchive($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip");
            }

            var path = $"{tempArchivesFolder}//{finalContainerName}";

            var memory = new MemoryStream();
            using (var stream = new FileStream(path, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;

            ClearTempFolder(tempArchivesFolder);

            return File(memory, GetContentType(path), Path.GetFileName(path));
        }

        private string GetContentType(string path)
        {
            var types = GetMimeTypes();
            var ext = Path.GetExtension(path).ToLowerInvariant();
            return types[ext];
        }

        private Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
            {
                {".txt", "text/plain"},
                {".pdf", "application/pdf"},
                {".doc", "application/vnd.ms-word"},
                {".docx", "application/vnd.ms-word"},
                {".xls", "application/vnd.ms-excel"},
                {".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
                {".png", "image/png"},
                {".jpg", "image/jpeg"},
                {".jpeg", "image/jpeg"},
                {".gif", "image/gif"},
                {".csv", "text/csv"}
            };
        }

        [HttpPost]
        [Route("/api/uploadFileToExtract")]
        public async Task UploadToExtract(IFormFile file, string extractMessageLanguage)
        {
            if (file == null) throw new Exception("File is null");
            if (file.Length == 0) throw new Exception("File is empty");

            if (file.Length > 0)
            {
                ClearTempFolder(tempArchivesFolder);
                using (var stream = new FileStream(Path.Combine(tempArchivesFolder, file.FileName), FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
            }

            fileName = file.FileName;
            fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);

            FileManager.CopyFileAndChangeExtentionToZip(Path.Combine(tempArchivesFolder, file.FileName));

            string xmlDocument = FileManager.ReadDocumentFromZipFile($"{tempArchivesFolder}//{fileNameWithoutExtension}.zip");

            DOCXFileWithMessage = new DOCXFile();
            DOCXFileWithMessage.document = new XMLFile();
            DOCXFileWithMessage.document.File = new StringBuilder(xmlDocument);

            try
            {
                messageLanguage = (SecretMessageLanguage)Enum.Parse(typeof(SecretMessageLanguage), extractMessageLanguage);
            }
            catch (Exception e)
            {
                messageLanguage = SecretMessageLanguage.ENGLISH;
            }

            string extractedMessage = Extracter.ExtractMessage(DOCXFileWithMessage.document, BitsPerSymbolHelper.numOfBits[messageLanguage]);      

            StegoContainerInfoDTO dto = new StegoContainerInfoDTO()
            {
                Name = file.FileName,
                BitsPerSymbol = BitsPerSymbolHelper.numOfBits[messageLanguage],
                EmbeddingMessage = extractedMessage,
                FinalContainerName = file.FileName,
                Size = 0
            };

            ClearTempFolder(tempArchivesFolder);

            var jsonString = JsonConvert.SerializeObject(dto);
            byte[] data = Encoding.UTF8.GetBytes(jsonString);
            await Response.Body.WriteAsync(data, 0, data.Length);
        }

    }
}